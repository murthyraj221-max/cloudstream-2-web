# Privacy Audit

Audit date: 2026-09-14

## Collection summary

The repository contains no analytics SDK, advertising SDK, tracking pixel, fingerprinting library, telemetry backend or account service.

There is no login requirement and no remote watch-history service.

## Local data

| Data | Location | Protection | Deletion |
|---|---|---|---|
| Title metadata | IndexedDB `titles` | Plain metadata; not account-secret data | Wipe/import/update |
| Bookmarks | IndexedDB `secure` | AES-GCM | Item deletion / wipe |
| Watchlist | IndexedDB `secure` | AES-GCM | Item deletion / wipe |
| Progress | IndexedDB `secure` | AES-GCM | Reset / wipe |
| History | IndexedDB `secure` | AES-GCM | Individual clear / retention / wipe |
| Collections | IndexedDB `secure` | AES-GCM | Collection deletion / wipe |
| Repository metadata | IndexedDB `secure` | AES-GCM | Repository deletion / wipe |
| Extension state | IndexedDB `secure` | AES-GCM | Uninstall / wipe |
| Settings | IndexedDB `secure` | AES-GCM | Change / wipe |
| Download metadata | IndexedDB `secure` | AES-GCM | Remove / wipe |
| Download bytes | IndexedDB `downloadChunks` | AES-GCM encrypted with the application DEK and SHA-256 integrity checked | Remove / wipe |
| PIN verifier | IndexedDB `meta` bootstrap | Salted PBKDF2 verifier; no raw PIN | Disable PIN / wipe |
| Wrapped DEK | IndexedDB `meta` bootstrap | Wrapped by installation or PIN-derived key | Rotate on PIN change / wipe |

## Networked data

Network activity occurs only for:

- user-configured repository URLs;
- explicitly installed declarative provider endpoints that pass origin/permission checks;
- explicitly selected authorized media sources;
- explicitly selected subtitle URLs;
- optional remote playback APIs exposed by the browser.

Service-worker caching does not intentionally cache cross-origin media or external private responses.

## Cookies and third-party services

No application code intentionally sets application cookies, and no third-party analytics/advertising service is bundled.

## Privacy UX

Settings includes a Privacy Center describing local storage, encryption and network behavior plus local-data wipe controls.

## Browser boundary

The app cannot guarantee privacy against a compromised browser profile, malicious browser extension, operating-system compromise, or developer tools access to the user's unlocked browser origin. Browser-side encryption and PIN locking are defense-in-depth, not device security.
