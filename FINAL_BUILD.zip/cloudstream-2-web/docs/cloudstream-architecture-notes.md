# CloudStream 2.0 Web — Architecture Notes

Audit/revision date: 2026-09-14

## 1. Authoritative upstream facts

The upstream CloudStream project is an extension-based multimedia player/media center. Its current README describes bookmarks, Chromecast/TV use, no ads/no tracking, and an extension system; it also states that the default application does not provide video sources and that extensions provide additional functionality.

References:
- Main repository: https://github.com/recloudstream/cloudstream
- Official extensions: https://github.com/recloudstream/extensions
- Repository manifest: https://github.com/recloudstream/extensions/blob/master/repo.json
- Provider documentation: https://recloudstream.github.io/csdocs/devs/create-your-own-providers/

The official extensions repository exposes a repository manifest with `manifestVersion: 1` and `pluginLists` and contains native provider projects. The native application/plugin model is Kotlin/Android oriented; the web project therefore treats that source as behavioral/architectural reference rather than as executable browser code.

The official provider documentation describes provider operations including home/discovery, search, result/details and video-link/source resolution.

## 2. Web adaptation

The web project keeps the responsibility boundaries but replaces native plugin execution with a browser-safe declarative provider protocol:

```text
Repository
  -> fetch + size/URL validation
  -> repository JSON
  -> plugin-list discovery
  -> WebExtension manifest validation
  -> explicit user installation
  -> capability/permission policy
  -> module Worker runtime
  -> capability-brokered HTTPS request
  -> normalized Provider
```

The application modules are:

- `src/app` — routing, screen composition, UI event wiring
- `src/core` — normalized domain types
- `src/storage` — IndexedDB schema, migrations, encrypted records
- `src/security` — Web Crypto, PIN/key hierarchy, URL validation, backup, sanitization
- `src/extensions` — manifest/repository/install/runtime security
- `src/providers` — provider registry and the local demo provider
- `src/search` — concurrent multi-provider search and ranking
- `src/library` — bookmarks/watchlist/collections/library mutations
- `src/history` — playback history and retention cleanup
- `src/player` — HTML media controller and Media Session integration
- `src/downloads` — authorized download queue and chunk storage
- `src/settings` — persisted preferences
- `src/pwa` — install/update/service-worker integration

## 3. Extension security deviation

Native `.cs3` plugin execution is intentionally unsupported. A browser application must not download arbitrary CloudStream-native code and execute it as page-origin JavaScript.

The replacement protocol is declarative. Provider manifests declare operations, permissions, origins and endpoint mappings. Provider requests are made by a dedicated Worker and are limited by the manifest allowlist, `credentials: omit`, redirect rejection, response limits and timeouts.

The application never uses `eval`, `new Function`, remote `<script>` injection, or dynamic execution of extension source.

Native-only entries from CloudStream-style plugin lists are skipped rather than executed.

## 4. Storage and key hierarchy

Version 3 of the application database contains legacy stores plus the current encrypted `secure` store, `meta` bootstrap state and `downloadChunks`.

Private records are encrypted using a random AES-GCM 256-bit data-encryption key (DEK).

```text
                     +-------------------+
PIN (optional) ----> | PBKDF2-SHA-256    |
                     | 310,000 iterations|
                     +---------+---------+
                               |
                               v
                      AES-GCM wrapping key
                               |
                               v
                       wrapped random DEK
                               |
                               v
                         encrypted records
```

The DEK is never persisted as raw key material. With app lock disabled, a random installation wrapping key protects it. With PIN lock enabled, the DEK is wrapped by a PIN-derived AES-GCM key. PIN changes re-wrap the existing DEK rather than re-encrypting every record.

The current implementation keeps the installation wrapping key as browser-managed `CryptoKey` material in IndexedDB. Browser storage remains origin-accessible to a compromised local/browser profile; this is not equivalent to hardware-backed device keystore protection.

## 5. Backup

Backups are JSON envelopes encrypted with AES-GCM using a PBKDF2-SHA-256 password-derived key. Authentication is provided by AES-GCM. Import validates the decrypted schema before mutation and restores titles and private records; download byte chunks are intentionally not exported.

## 6. Player

The player is a browser-native `HTMLMediaElement` controller with capability detection. It supports actual source switching, persisted resume seeking, progress/history, episode changes, WebVTT/local VTT, playback speed, fullscreen, PiP, Media Session and remote playback picker APIs where exposed by the browser.

No fake quality/audio/cast controls are shown when the underlying browser capability is unavailable.

## 7. Downloads

Authorized sources can be streamed into chunked IndexedDB storage. Chunks are SHA-256 verified. The queue supports pause/resume/retry/cancel/progress/reconstruction. Browser quota and background execution remain platform constraints.

## 8. Service worker

`public/sw.js` is the sole service worker. It caches the application shell and same-origin assets only, versions/cleans its cache, falls back to `/index.html` for same-origin navigations, and ignores cross-origin media/network requests. It does not silently cache private media.

## 9. Security boundaries

The application blocks insecure and private repository/source destinations at the browser boundary, rejects credential-bearing URLs, limits repository/manifest/response sizes, rejects unvalidated redirects, validates endpoint origins against manifest allowlists and does not expose cookies, DOM or credentials to providers.

There is no application-side arbitrary URL proxy; therefore server-side SSRF/DNS rebinding controls are not applicable to the current architecture.

## 10. Known browser limitations

- Native CloudStream `.cs3` code cannot be executed safely as a web extension.
- Declarative providers require browser CORS compatibility.
- Audio-track selection depends on browser/media `audioTracks` support.
- Remote playback depends on browser/device APIs.
- iOS background execution and unrestricted background downloads remain platform limited.
- Browser-side PIN protection is not hardware-backed OS security.
- Full HLS/DASH/DRM behavior depends on the browser's native media stack.
