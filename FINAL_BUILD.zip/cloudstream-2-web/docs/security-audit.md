# Security Audit

Audit date: 2026-09-14

## Threat model

Primary threats:

- hostile metadata from providers;
- malicious repository manifests;
- malicious provider responses;
- unsafe media/subtitle URLs;
- malicious backup files;
- extension permission escalation;
- remote JavaScript execution attempts;
- service-worker cache abuse;
- accidental retention of private history;
- unauthorized local-origin access.

Out of scope for the current client-only architecture:

- server-side SSRF/DNS rebinding, because no server URL proxy is implemented;
- OS/kernel compromise;
- browser-vendor vulnerabilities;
- hardware-backed keystore guarantees.

## Security controls

### CSP

Cloudflare Pages `_headers` deploys a same-origin policy with `script-src 'self'`, `object-src 'none'`, `base-uri 'none'`, `frame-ancestors 'none'`, `form-action 'self'`, `worker-src 'self' blob:` and HTTPS-only network/media origins. `unsafe-inline` is absent.

### Headers

Configured:

- Strict-Transport-Security
- Content-Security-Policy
- Referrer-Policy: no-referrer
- Permissions-Policy
- X-Content-Type-Options: nosniff
- Cross-Origin-Opener-Policy
- Cross-Origin-Resource-Policy
- X-DNS-Prefetch-Control: off

### URL/network validation

Remote destinations must use HTTPS, reject credentials and unsafe ports, and block localhost, loopback, RFC1918/private and link-local ranges plus known metadata hostnames. Provider endpoint URLs are constrained to manifest-declared HTTPS origins. Fetches omit credentials and reject redirects.

### Extension isolation

Provider execution uses a module Worker. The runtime has operation timeouts and terminates/recreates timed-out workers. Endpoint requests are capability/permission checked and origin allowlisted. Providers do not receive page DOM, cookies, localStorage or credentials.

The declarative runtime deliberately does not execute arbitrary remote JavaScript.

### Manifest and repository validation

Manifests are bounded and schema checked. Capabilities, permissions, IDs, versions, origins, dependencies, endpoint methods/headers and response-path metadata are validated. Repository responses and plugin lists have size/count limits.

SHA-256 integrity and optional Ed25519 publisher verification are supported. A manifest is not marked trusted/verified merely because it is valid JSON or contains a self-declared hash/signature. A trusted publisher anchor is required for future verified status.

### XSS

External values are HTML-escaped before use in the current templating paths, and a dedicated sanitization helper is used for provider/local subtitle markup. No remote script injection is permitted. The application avoids remote `<script>` loading.

The remaining `innerHTML` use is limited to application-controlled UI templates; external provider values are escaped before interpolation and the player subtitle-option update uses DOM APIs.

### Storage encryption

Private structured records are encrypted with AES-GCM under a random 256-bit DEK. The DEK is wrapped by an installation key or PIN-derived AES-GCM key. The PIN is represented only by a salted PBKDF2 verifier and is never stored raw.

### PIN security

- 4–8 numeric digits;
- PBKDF2-SHA-256 with 310,000 iterations;
- random salt;
- progressive retry backoff;
- inactivity auto-lock;
- lock-on-hidden option;
- manual lock;
- data key dropped from active JS state on lock.

### Backup security

Backups use AES-GCM authenticated encryption and PBKDF2 password derivation. Decrypted backups pass structural validation before restore. Import restores are wrapped in a rollback path so failed mutation does not intentionally leave a half-restored state.

### Service worker

Only same-origin requests are handled. Static shell/cache resources are explicitly selected. Cross-origin media requests are ignored. Old cache versions are removed during activation.

## Security test coverage

Automated tests cover:

- insecure/private URL attacks;
- origin allowlist violations;
- malformed capabilities/permissions;
- manifest attacks;
- redirect rejection;
- backup tampering;
- PIN verification;
- cryptographic wrapping/wrong-password behavior;
- absence of executable remote-code primitives;
- service-worker same-origin/cache rules;
- production CSP/unsafe-inline/security-token scans.

## Known limitations

- browser storage and CryptoKey material are still governed by browser origin security;
- no hardware-backed keystore;
- no native `.cs3` sandbox compatibility;
- Ed25519 support depends on browser Web Crypto availability;
- no server-side SSRF surface exists today, so a future proxy would require a separate hardened server threat model.

## Latest hardening pass

- Added IPv4-mapped IPv6 private-address detection after URL canonicalization.
- Added conservative trust semantics so self-declared integrity metadata cannot elevate trust.
- Added subtitle style presets without inline style attributes.
- Added adversarial trust and mapped-IPv6 tests.
