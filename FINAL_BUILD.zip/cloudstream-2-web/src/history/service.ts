import type {HistoryItem} from '../core/types.js';
import {allSecure,putSecure,removeSecure,secureClear} from '../storage/db.js';
export async function recordHistory(titleKey:string){const key=`history:${titleKey}`;await putSecure('history',key,{key,titleKey,playedAt:Date.now()} satisfies HistoryItem);}
export async function history(){return allSecure<HistoryItem>('history');}
export async function removeHistory(key:string){await removeSecure('history',key);}
export async function clearHistory(){await secureClear('history');}
export async function pruneHistory(days:number){if(days<=0){await clearHistory();return;}const cutoff=Date.now()-days*86400000;for(const x of await history())if(x.playedAt<cutoff)await removeHistory(x.key);}
