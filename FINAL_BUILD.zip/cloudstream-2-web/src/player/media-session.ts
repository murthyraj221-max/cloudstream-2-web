export function setupMediaSession(title:string,video:HTMLVideoElement){
  if(!('mediaSession' in navigator))return;
  try{navigator.mediaSession.metadata=new MediaMetadata({title});
    const set=(action:MediaSessionAction,fn:()=>void)=>{try{navigator.mediaSession.setActionHandler(action,fn);}catch{}};
    set('play',()=>void video.play()); set('pause',()=>video.pause()); set('seekbackward',()=>video.currentTime=Math.max(0,video.currentTime-10)); set('seekforward',()=>video.currentTime=Math.min(video.duration||Infinity,video.currentTime+10));
  }catch{}
}
