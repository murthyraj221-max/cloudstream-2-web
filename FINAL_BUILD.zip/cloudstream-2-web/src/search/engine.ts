import type {Provider,SearchResult,Title} from '../core/types.js';
import {demoContext} from '../providers/demo.js';
export interface SearchFilters{type?:Title['type'];year?:number;language?:string;genre?:string;sort:'relevance'|'title'|'year';}
function score(result:SearchResult,q:string){const n=q.trim().toLowerCase();const t=result.title.title.toLowerCase();let s=result.score??0;if(t===n)s+=100;else if(t.startsWith(n))s+=50;else if(t.includes(n))s+=25;s+=Math.min(result.sourceCount,10);return s;}
export async function searchProviders(q:string,providers:Provider[],signal:AbortSignal,filters:SearchFilters):Promise<{results:SearchResult[];failures:string[]}> {
 const tasks=providers.map(async p=>{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),9000);const abort=()=>controller.abort();signal.addEventListener('abort',abort,{once:true});try{const value=await p.search(q,{signal:controller.signal,fetchJson:demoContext(signal).fetchJson});p.status='online';return value;}catch(e){p.status=signal.aborted?'unknown':'offline';if(signal.aborted)throw e;return null;}finally{clearTimeout(timer);signal.removeEventListener('abort',abort);}});
 const settled=await Promise.allSettled(tasks);const all:SearchResult[]=[];const failures:string[]=[];settled.forEach((s,i)=>{if(s.status==='fulfilled'&&s.value)all.push(...s.value);else if(providers[i])failures.push(providers[i].name);});
 const dedup=new Map<string,SearchResult>();for(const r of all){const key=`${r.title.title.toLowerCase()}|${r.title.year??''}|${r.title.type}`;const existing=dedup.get(key);if(!existing||score(r,q)>score(existing,q))dedup.set(key,{...r,score:score(r,q)});}
 let out=[...dedup.values()].filter(r=>!filters.type||r.title.type===filters.type).filter(r=>!filters.year||r.title.year===filters.year).filter(r=>!filters.language||r.title.language?.toLowerCase()===filters.language.toLowerCase()).filter(r=>!filters.genre||r.title.genres.some(g=>g.toLowerCase()===filters.genre!.toLowerCase()));
 if(filters.sort==='title')out.sort((a,b)=>a.title.title.localeCompare(b.title.title));else if(filters.sort==='year')out.sort((a,b)=>(b.title.year??0)-(a.title.year??0));else out.sort((a,b)=>(b.score??0)-(a.score??0));
 return {results:out,failures};
}
