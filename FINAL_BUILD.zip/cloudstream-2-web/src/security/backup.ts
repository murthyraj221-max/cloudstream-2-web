import {decryptJson,encryptJson} from './crypto.js';
import {allSecure,allTitles,getRepositories,putSecure,removeSecure,secureClear,saveRepository,putTitle,clearTitles} from '../storage/db.js';
import type {BackupPayload,Bookmark,Collection,DownloadJob,HistoryItem,InstalledExtension,Repository,Settings,Title,WatchProgress} from '../core/types.js';

const SECTION_LIMITS:Record<string,number>={titles:10000,bookmarks:10000,progress:20000,history:20000,collections:5000,downloads:5000,repositories:100,extensions:500,settings:10};
const SECTIONS=Object.keys(SECTION_LIMITS);
function plainObject(x:unknown):x is Record<string,unknown>{return Boolean(x)&&typeof x==='object'&&!Array.isArray(x);}
function validateSectionArray(name:string,value:unknown){if(!Array.isArray(value))throw new Error(`Invalid backup section: ${name}`);if(value.length>SECTION_LIMITS[name]!)throw new Error(`Backup section too large: ${name}`);for(const item of value){if(!plainObject(item)&&name!=='settings')throw new Error(`Invalid ${name} record.`);if(plainObject(item)&&JSON.stringify(item).length>100000)throw new Error(`Oversized ${name} record.`);}}
export function validateBackupPayload(x:unknown):BackupPayload{
  if(!plainObject(x)||x.schemaVersion!==1||typeof x.exportedAt!=='number'||!plainObject(x.records))throw new Error('Invalid backup schema.');
  if(Date.now()+86400000<x.exportedAt)throw new Error('Backup timestamp is invalid.');
  for(const name of SECTIONS)validateSectionArray(name,x.records[name]);
  const r=x.records;
  for(const t of r.titles as unknown[]){if(typeof (t as any).id!=='string'||typeof (t as any).title!=='string')throw new Error('Invalid title record.');}
  for(const b of r.bookmarks as unknown[]){if(typeof (b as any).key!=='string'||!['bookmark','watchlist'].includes((b as any).kind))throw new Error('Invalid bookmark record.');}
  for(const p of r.progress as unknown[]){if(typeof (p as any).key!=='string'||typeof (p as any).titleKey!=='string'||typeof (p as any).timestamp!=='number')throw new Error('Invalid progress record.');}
  for(const h of r.history as unknown[]){if(typeof (h as any).key!=='string'||typeof (h as any).titleKey!=='string'||typeof (h as any).playedAt!=='number')throw new Error('Invalid history record.');}
  for(const c of r.collections as unknown[]){if(typeof (c as any).id!=='string'||typeof (c as any).name!=='string'||!Array.isArray((c as any).titleKeys))throw new Error('Invalid collection record.');}
  for(const re of r.repositories as unknown[]){if(typeof (re as any).url!=='string'||typeof (re as any).name!=='string')throw new Error('Invalid repository record.');}
  for(const e of r.extensions as unknown[]){if(!plainObject((e as any).manifest)||typeof (e as any).manifest.id!=='string')throw new Error('Invalid extension record.');}
  const settings=r.settings as unknown[];if(settings.length>1)throw new Error('Multiple settings records are not allowed.');
  return x as unknown as BackupPayload;
}
export async function exportBackup(password:string){
  if(password.length<8)throw new Error('Backup password must be at least 8 characters.');
  const payload:BackupPayload={schemaVersion:1,exportedAt:Date.now(),records:{titles:await allTitles(),bookmarks:await allSecure('bookmarks'),progress:await allSecure('progress'),history:await allSecure('history'),collections:await allSecure('collections'),downloads:await allSecure('downloads'),repositories:await getRepositories(),extensions:await allSecure('extensions'),settings:await allSecure('settings')}};
  return encryptJson(payload,password);
}
export async function importBackup<T extends BackupPayload>(packed:string,password:string){const payload=validateBackupPayload(await decryptJson<T>(packed,password));return payload;}

export async function restoreBackup(payload:BackupPayload){
  const current={titles:await allTitles<Title>(),bookmarks:await allSecure<Bookmark>('bookmarks'),progress:await allSecure<WatchProgress>('progress'),history:await allSecure<HistoryItem>('history'),collections:await allSecure<Collection>('collections'),downloads:await allSecure<DownloadJob>('downloads'),repositories:await getRepositories(),extensions:await allSecure<InstalledExtension>('extensions'),settings:await allSecure<Settings>('settings')};
  try{
    await Promise.all([secureClear('bookmarks'),secureClear('progress'),secureClear('history'),secureClear('collections'),secureClear('downloads'),secureClear('extensions'),secureClear('settings'),secureClear('repositories')]);
    await clearTitles();
    for(const t of payload.records.titles as Title[])await putTitle(t);
    for(const b of payload.records.bookmarks as Bookmark[])await putSecure('bookmarks',b.key,b);
    for(const p of payload.records.progress as WatchProgress[])await putSecure('progress',p.key,p);
    for(const h of payload.records.history as HistoryItem[])await putSecure('history',h.key,h);
    for(const c of payload.records.collections as Collection[])await putSecure('collections',c.id,c);
    for(const d of payload.records.downloads as DownloadJob[])await putSecure('downloads',d.id,{...d,status:'failed',error:'Media bytes are not included in backups.'});
    for(const e of payload.records.extensions as InstalledExtension[])await putSecure('extensions',e.manifest.id,e);
    for(const r of payload.records.repositories as Repository[])await saveRepository(r);
    for(const st of payload.records.settings as Settings[])await putSecure('settings','settings',st);
  }catch(error){
    await Promise.all([secureClear('bookmarks'),secureClear('progress'),secureClear('history'),secureClear('collections'),secureClear('downloads'),secureClear('extensions'),secureClear('settings'),secureClear('repositories')]);
    await clearTitles();
    for(const t of current.titles)await putTitle(t);for(const b of current.bookmarks)await putSecure('bookmarks',b.key,b);for(const p of current.progress)await putSecure('progress',p.key,p);for(const h of current.history)await putSecure('history',h.key,h);for(const c of current.collections)await putSecure('collections',c.id,c);for(const d of current.downloads)await putSecure('downloads',d.id,d);for(const e of current.extensions)await putSecure('extensions',e.manifest.id,e);for(const r of current.repositories)await saveRepository(r);for(const st of current.settings)await putSecure('settings','settings',st);
    throw error;
  }
}
