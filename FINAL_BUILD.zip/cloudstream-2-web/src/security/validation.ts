const PRIVATE_V4 = /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/i;
const PRIVATE_V6 = /^(::1$|fc[0-9a-f]{2}:|fd[0-9a-f]{2}:|fe80:|febf:)/i;
const SAFE_METHODS = new Set(['GET','POST']);

export function isPrivateHostname(hostname:string):boolean {
  const h = hostname.replace(/^\[|\]$/g,'').toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h === 'metadata.google.internal') return true;
  const mappedMatch=h.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i);let mappedPrivate=false;if(mappedMatch){const a=Number.parseInt(mappedMatch[1]!,16),b=Number.parseInt(mappedMatch[2]!,16);const ipv4=`${a>>>8}.${a&255}.${b>>>8}.${b&255}`;mappedPrivate=PRIVATE_V4.test(ipv4);}
  if (PRIVATE_V4.test(h) || PRIVATE_V6.test(h) || mappedPrivate || /^::ffff:(?:(?:\d{1,3})\.){3}\d{1,3}$/i.test(h) && PRIVATE_V4.test(h.replace(/^::ffff:/i,'')) || h==='::' || /^0*:0*:0*:0*:0*:0*:0*:0*$/.test(h)) return true;
  return false;
}

export function validateHttpUrl(input:string, opts:{allowPrivate?:boolean;allowPort?:boolean}={}):URL {
  let u:URL;
  try { u = new URL(input); } catch { throw new Error('Invalid URL.'); }
  if (u.protocol !== 'https:') throw new Error('Only HTTPS URLs are allowed.');
  if (!opts.allowPrivate && isPrivateHostname(u.hostname)) throw new Error('Private or loopback hosts are blocked.');
  if (!opts.allowPort && u.port) throw new Error('Custom ports are blocked by default.');
  if (u.username || u.password) throw new Error('Credential-bearing URLs are blocked.');
  return u;
}

export function validateOrigin(input:string):string {
  const u = validateHttpUrl(input);
  if (!['/',''].includes(u.pathname) || u.search || u.hash) throw new Error('Origin must not contain a path, query, or fragment.');
  return u.origin;
}

const SAFE_HEADER=/^[A-Za-z0-9!#$%&'*+.^_`|~-]+$/;
const MAX_ENDPOINT_PATH=2048;
export function validateHeaderName(name:string){if(name.length>64||!SAFE_HEADER.test(name))throw new Error('Unsafe header name.');return name;}
export function validateEndpointHeaders(headers:Record<string,unknown>){const out:Record<string,string>={};const entries=Object.entries(headers);if(entries.length>12)throw new Error('Too many endpoint headers.');for(const [k,v] of entries){validateHeaderName(k);if(typeof v!=='string'||v.length>512)throw new Error('Invalid endpoint header.');if(/^(cookie|authorization|proxy-authorization|host)$/i.test(k))throw new Error(`Forbidden endpoint header: ${k}`);out[k]=v;}return out;}
export function validateEndpointUrl(input:string, allowedOrigins:string[]):URL {
  const u = validateHttpUrl(input);
  if (u.pathname.length>MAX_ENDPOINT_PATH) throw new Error('Endpoint path is too long.');
  if (!allowedOrigins.some(o => u.origin === validateOrigin(o))) throw new Error('Endpoint origin is not allowed by the extension manifest.');
  return u;
}

export function validateMethod(method?:string):'GET'|'POST' {
  const m=(method??'GET').toUpperCase();
  if(!SAFE_METHODS.has(m)) throw new Error('Only GET and POST are allowed.');
  return m as 'GET'|'POST';
}

export function limitText(input:string,max:number):string { if(input.length>max) throw new Error(`Input exceeds ${max} characters.`); return input; }
export function safeFilename(name:string):string { return name.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').slice(0,180)||'download'; }

export function compareVersions(a:string,b:string):number {
  const normalize=(s:string)=>s.replace(/^v/i,'').split('.').map(x=>Number.parseInt(x,10)||0);
  const pa=normalize(a),pb=normalize(b);
  for(let i=0;i<Math.max(pa.length,pb.length);i++){const d=(pa[i]??0)-(pb[i]??0);if(d)return d;}
  return 0;
}

export function isSha256(value:string):boolean { return /^[a-f0-9]{64}$/i.test(value); }
