const enc = new TextEncoder(), dec = new TextDecoder();
export const KDF_ITERATIONS = 310000;

function b64(buf: ArrayBuffer): string {
  let out = '';
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) out += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(out);
}
function unb64(s: string): Uint8Array { return Uint8Array.from(atob(s), c => c.charCodeAt(0)); }

export interface WrappedKey { version: 2; algorithm: 'AES-GCM'; salt: string; iv: string; wrapped: string; }

async function derive(password: string, salt: ArrayBuffer, usages: KeyUsage[] = ['encrypt','decrypt']): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: KDF_ITERATIONS, hash: 'SHA-256' }, base, 256);
  return crypto.subtle.importKey('raw', bits, { name: 'AES-GCM' }, false, usages);
}

export async function deriveAesKey(password: string, salt: Uint8Array, usages: KeyUsage[] = ['encrypt','decrypt']): Promise<CryptoKey> {
  return derive(password, salt.buffer.slice(salt.byteOffset, salt.byteOffset + salt.byteLength), usages);
}
export async function generateDataKey(): Promise<CryptoKey> {
  return crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt','decrypt']);
}
export async function generateWrappingKey(): Promise<CryptoKey> {
  return crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['wrapKey','unwrapKey']);
}
export async function wrapDataKeyWithPassword(dataKey: CryptoKey, password: string): Promise<WrappedKey> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const wrapKey = await deriveAesKey(password, salt, ['wrapKey','unwrapKey']);
  const wrapped = await crypto.subtle.wrapKey('raw', dataKey, wrapKey, { name: 'AES-GCM', iv });
  return { version: 2, algorithm: 'AES-GCM', salt: b64(salt.buffer), iv: b64(iv.buffer), wrapped: b64(wrapped) };
}
export async function unwrapDataKeyWithPassword(wrapped: WrappedKey, password: string): Promise<CryptoKey> {
  const salt = unb64(wrapped.salt), iv = unb64(wrapped.iv);
  const wrapKey = await deriveAesKey(password, salt, ['wrapKey','unwrapKey']);
  return crypto.subtle.unwrapKey('raw', unb64(wrapped.wrapped), wrapKey, { name: 'AES-GCM', iv }, { name: 'AES-GCM', length: 256 }, true, ['encrypt','decrypt']);
}
export async function wrapDataKeyWithKey(dataKey: CryptoKey, wrappingKey: CryptoKey): Promise<{version:2;algorithm:'AES-GCM';iv:string;wrapped:string}> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const wrapped = await crypto.subtle.wrapKey('raw', dataKey, wrappingKey, { name:'AES-GCM', iv });
  return { version: 2, algorithm:'AES-GCM', iv:b64(iv.buffer), wrapped:b64(wrapped) };
}
export async function unwrapDataKeyWithKey(wrapped: {version:2;algorithm:'AES-GCM';iv:string;wrapped:string}, wrappingKey: CryptoKey): Promise<CryptoKey> {
  return crypto.subtle.unwrapKey('raw', unb64(wrapped.wrapped), wrappingKey, { name:'AES-GCM', iv:unb64(wrapped.iv) }, { name:'AES-GCM', length:256 }, true, ['encrypt','decrypt']);
}

async function encryptWithKey(value: unknown, key: CryptoKey) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, key, enc.encode(JSON.stringify(value)));
  return { iv:b64(iv.buffer), cipher:b64(cipher) };
}
async function decryptWithKey<T>(packed:{iv:string;cipher:string}, key:CryptoKey) {
  const plain = await crypto.subtle.decrypt({ name:'AES-GCM', iv:unb64(packed.iv) }, key, unb64(packed.cipher));
  return JSON.parse(dec.decode(plain)) as T;
}
export async function encryptRecord(value:unknown,key:CryptoKey){ return encryptWithKey(value,key); }
export async function decryptRecord<T>(packed:{iv:string;cipher:string},key:CryptoKey){ return decryptWithKey<T>(packed,key); }
export async function encryptBytes(bytes:ArrayBuffer,key:CryptoKey){return encryptWithKey({b64:b64(bytes)},key);}
export async function decryptBytes(packed:{iv:string;cipher:string},key:CryptoKey){const x=await decryptWithKey<{b64:string}>(packed,key);return unb64(x.b64).buffer;}

export async function encryptJson(value:unknown,password:string){
  const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await deriveAesKey(password,salt);
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(JSON.stringify(value)));
  return JSON.stringify({v:2,salt:b64(salt.buffer),iv:b64(iv.buffer),cipher:b64(cipher)});
}
export async function decryptJson<T>(packed:string,password:string){
  const x=JSON.parse(packed) as {v:number;salt:string;iv:string;cipher:string};
  if(x.v!==2&&x.v!==1)throw new Error('Unsupported backup version.');
  const key=await deriveAesKey(password,unb64(x.salt));
  const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(x.iv)},key,unb64(x.cipher));
  return JSON.parse(dec.decode(plain)) as T;
}

async function derivePinBits(pin:string,salt:Uint8Array){
  const base=await crypto.subtle.importKey('raw',enc.encode(pin),'PBKDF2',false,['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:KDF_ITERATIONS,hash:'SHA-256'},base,256));
}
export async function hashPin(pin:string){const salt=crypto.getRandomValues(new Uint8Array(16));const raw=await derivePinBits(pin,salt);return {salt:b64(salt.buffer),hash:b64(raw.buffer),iterations:KDF_ITERATIONS};}
export async function verifyPin(pin:string,stored:{salt:string;hash:string;iterations?:number}){
  const base=await crypto.subtle.importKey('raw',enc.encode(pin),'PBKDF2',false,['deriveBits']);
  const raw=new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:unb64(stored.salt),iterations:stored.iterations??KDF_ITERATIONS,hash:'SHA-256'},base,256));
  const expected=unb64(stored.hash);if(raw.length!==expected.length)return false;let diff=0;for(let i=0;i<raw.length;i++)diff|=raw[i]!^expected[i]!;return diff===0;
}
export async function sha256Hex(data:BufferSource|string){const bytes=typeof data==='string'?enc.encode(data):data;const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');}
export function canonicalize(value:unknown):string{if(value===undefined)return 'null';if(value===null||typeof value!=='object')return JSON.stringify(value);if(Array.isArray(value))return `[${value.map(canonicalize).join(',')}]`;const obj=value as Record<string,unknown>;return `{${Object.keys(obj).filter(k=>obj[k]!==undefined).sort().map(k=>`${JSON.stringify(k)}:${canonicalize(obj[k])}`).join(',')}}`;}
export async function verifyEd25519(publicKeyB64:string,signatureB64:string,data:string){try{const key=await crypto.subtle.importKey('raw',unb64(publicKeyB64),{name:'Ed25519'},false,['verify']);return crypto.subtle.verify({name:'Ed25519'},key,unb64(signatureB64),enc.encode(data));}catch{return false;}}
export function secureEqual(a:string,b:string){if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0;}
