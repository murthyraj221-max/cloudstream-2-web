const ESCAPE:Record<string,string>={'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'};
export function escapeHtml(value:unknown):string{return String(value).replace(/[&<>\'"]/g,c=>ESCAPE[c]!);}
export function stripUnsafeSubtitleMarkup(value:string):string{return value.replace(/<[^>]*>/g,'').replace(/(?:javascript|data):/gi,'');}
