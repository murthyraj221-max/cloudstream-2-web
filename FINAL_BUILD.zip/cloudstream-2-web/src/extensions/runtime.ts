import type {EpisodeContext,Provider,SearchResult,Source,Subtitle,Title,WebExtensionManifest} from '../core/types.js';
import {manifestTrustState} from './manifest.js';

export class ExtensionRuntime{
  private worker?:Worker; private seq=0; private pending=new Map<number,{resolve:(x:unknown)=>void;reject:(e:Error)=>void;timer:number;signal?:AbortSignal;abort:()=>void}>();
  constructor(private manifest:WebExtensionManifest){this.spawn();}
  private spawn(){this.worker=new Worker(new URL('./runtime-worker.js',import.meta.url),{type:'module'});this.worker.onmessage=(e:MessageEvent)=>{const m=e.data as {id:number;ok:boolean;result?:unknown;error?:string};const p=this.pending.get(m.id);if(!p)return;this.pending.delete(m.id);window.clearTimeout(p.timer);p.signal?.removeEventListener('abort',p.abort);m.ok?p.resolve(m.result):p.reject(new Error(m.error||'Provider call failed.'));};}
  private call<T>(op:'search'|'metadata'|'sources'|'subtitles'|'home',input:Record<string,string>,signal:AbortSignal):Promise<T>{
    if(signal.aborted)return Promise.reject(new DOMException('Aborted','AbortError'));
    return new Promise((resolve,reject)=>{const id=++this.seq;const timer=window.setTimeout(()=>{this.worker?.terminate();this.spawn();this.pending.delete(id);reject(new Error('Extension provider timed out.'));},10000);const abort=()=>{this.worker?.postMessage({id,abort:true});const p=this.pending.get(id);if(p){window.clearTimeout(p.timer);this.pending.delete(id);p.reject(new DOMException('Aborted','AbortError'));}};this.pending.set(id,{resolve:resolve as (x:unknown)=>void,reject,timer,signal,abort});signal.addEventListener('abort',abort,{once:true});this.worker?.postMessage({id,op,manifest:this.manifest,input});});
  }
  search(q:string,s:AbortSignal){return this.call<SearchResult[]>('search',{q},s);} 
  metadata(t:Title,s:AbortSignal){return this.call<Title>('metadata',{id:t.id,q:t.title},s);} 
  sources(t:Title,s:AbortSignal,ep?:EpisodeContext){return this.call<Source[]>('sources',{id:t.id,q:t.title,season:ep?.season===undefined?'':String(ep.season),episode:ep?.episode===undefined?'':String(ep.episode)},s);} 
  subtitles(t:Title,s:AbortSignal,ep?:EpisodeContext){return this.call<Subtitle[]>('subtitles',{id:t.id,q:t.title,season:ep?.season===undefined?'':String(ep.season),episode:ep?.episode===undefined?'':String(ep.episode)},s);} 
  home(s:AbortSignal){return this.call<SearchResult[]>('home',{},s);} 
  terminate(){this.worker?.terminate();this.worker=undefined;for(const [id,p] of this.pending){window.clearTimeout(p.timer);p.reject(new Error('Extension runtime terminated.'));this.pending.delete(id);}}
}
export function createProvider(manifest:WebExtensionManifest):Provider{const runtime=new ExtensionRuntime(manifest);const caps=new Set(manifest.capabilities);return {id:manifest.id,name:manifest.name,version:manifest.version,description:manifest.description,capabilities:manifest.capabilities,trust:manifestTrustState(manifest),status:'unknown',search:(q,ctx)=>caps.has('search')?runtime.search(q,ctx.signal):Promise.resolve([]),getMetadata:(t,ctx)=>caps.has('metadata')?runtime.metadata(t,ctx.signal):Promise.resolve(t),getSources:(t,ctx,ep)=>caps.has('sources')?runtime.sources(t,ctx.signal,ep):Promise.resolve([]),getSubtitles:(t,ctx,ep)=>caps.has('subtitles')?runtime.subtitles(t,ctx.signal,ep):Promise.resolve([]),getHome:(ctx)=>caps.has('home')?runtime.home(ctx.signal):Promise.resolve([])};}
