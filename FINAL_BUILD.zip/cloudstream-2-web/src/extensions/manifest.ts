import type {Capability, EndpointSpec, InstalledExtension, Permission, WebExtensionManifest} from '../core/types.js';
import {isSha256, limitText, validateEndpointHeaders, validateEndpointUrl, validateHttpUrl, validateMethod, validateOrigin} from '../security/validation.js';

const capabilities:Capability[]=['search','metadata','sources','subtitles','home'];
const permissions:Permission[]=['search','metadata','sources','subtitles','home','network','storage'];
const ID=/^[a-zA-Z0-9][a-zA-Z0-9._-]{1,63}$/;

function endpoint(x:unknown, origins:string[]):EndpointSpec|undefined{
  if(x===undefined)return undefined;
  if(!x||typeof x!=='object')throw new Error('Endpoint must be an object.');
  const e=x as Record<string,unknown>;
  if(typeof e.url!=='string')throw new Error('Endpoint URL is required.');
  const u=validateEndpointUrl(e.url,origins);
  const method=validateMethod(typeof e.method==='string'?e.method:undefined);
  if(e.query!==undefined && (!e.query || typeof e.query!=='object'))throw new Error('Endpoint query must be an object.');
  if(e.headers!==undefined && (!e.headers || typeof e.headers!=='object'))throw new Error('Endpoint headers must be an object.');
  const resultMap=e.resultMap===undefined?undefined:((typeof e.resultMap==='object'&&e.resultMap!==null)?Object.fromEntries(Object.entries(e.resultMap).map(([k,v])=>[k,String(v)])):undefined);
  if(e.resultMap!==undefined&&!resultMap)throw new Error('Endpoint resultMap must be an object.');
  const headers=e.headers===undefined?undefined:validateEndpointHeaders(e.headers as Record<string,unknown>);
  if(e.query!==undefined){for(const [k,v] of Object.entries(e.query as Record<string,unknown>)){if(k.length>64||typeof v!=='string'||String(v).length>512)throw new Error('Invalid endpoint query.');}}
  if(e.body!==undefined && JSON.stringify(e.body).length>16384)throw new Error('Endpoint body is too large.');
  return {url:u.toString(),method,query:e.query as Record<string,string>|undefined,headers,body:e.body,responsePath:typeof e.responsePath==='string'?e.responsePath:undefined,resultMap};
}

export function validateManifest(x:unknown):WebExtensionManifest{
  if(!x||typeof x!=='object')throw new Error('Manifest must be an object.');
  const m=x as Record<string,unknown>;
  for(const k of ['id','name','version','description','author'])if(typeof m[k]!=='string'||!String(m[k]).trim())throw new Error(`Missing manifest field: ${k}`);
  if(m.manifestVersion!==1)throw new Error('Unsupported manifestVersion.');
  if(!ID.test(String(m.id)))throw new Error('Invalid extension id.');
  if(!/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(String(m.version)))throw new Error('Version must be semantic x.y.z.');
  limitText(String(m.name),120); limitText(String(m.description),4000); limitText(String(m.author),160);
  const caps=Array.isArray(m.capabilities)?m.capabilities.map(String) as Capability[]:[];
  if(!caps.length||caps.some(c=>!capabilities.includes(c)))throw new Error('Invalid capabilities.');
  const perms=Array.isArray(m.permissions)?m.permissions.map(String) as Permission[]:caps.filter(c=>c!=='home');
  if(perms.some(p=>!permissions.includes(p)))throw new Error('Invalid permission.');
  if(caps.some(c=>!perms.includes(c as Permission)) && caps.some(c=>c!=='home'))throw new Error('Each capability must be permissioned.');
  const origins=Array.isArray(m.origins)?m.origins.map(String):[];
  if(!origins.length||origins.length>12)throw new Error('Invalid origins list.');
  const cleanOrigins=[...new Set(origins.map(validateOrigin))];
  const homepage=m.homepage===undefined?undefined:validateHttpUrl(String(m.homepage)).toString();
  if(JSON.stringify(x).length>200000)throw new Error('Manifest is too large.');
  const deps=Array.isArray(m.dependencies)?m.dependencies.map(String):[]; if(deps.length>12||deps.some(d=>!ID.test(d)))throw new Error('Invalid dependencies.');
  if(new Set(caps).size!==caps.length||new Set(perms).size!==perms.length)throw new Error('Duplicate capabilities or permissions.');
  const sha=m.sha256===undefined?undefined:String(m.sha256); if(sha&&!isSha256(sha))throw new Error('sha256 must be 64 hex characters.');
  const provider=m.provider;
  if(!provider||typeof provider!=='object')throw new Error('Declarative provider definition is required.');
  const p=provider as Record<string,unknown>;
  return {manifestVersion:1,id:String(m.id),name:String(m.name),version:String(m.version),description:String(m.description),author:String(m.author),homepage,capabilities:caps,permissions:perms,origins:cleanOrigins,sha256:sha,publisher:typeof m.publisher==='object'&&m.publisher!==null?m.publisher as WebExtensionManifest['publisher']:undefined,dependencies:deps,provider:{search:endpoint(p.search,cleanOrigins),metadata:endpoint(p.metadata,cleanOrigins),sources:endpoint(p.sources,cleanOrigins),subtitles:endpoint(p.subtitles,cleanOrigins),home:endpoint(p.home,cleanOrigins)}};
}

export function manifestTrustState(_manifest:WebExtensionManifest):'Unverified' { return 'Unverified'; }

export function installedFromManifest(manifest:WebExtensionManifest,repositoryUrl:string,status:InstalledExtension['status']='unknown'):InstalledExtension{return {manifest,enabled:true,installedAt:Date.now(),repositoryUrl,status};}
