import type {Bookmark,Collection,DownloadJob,HistoryItem,InstalledExtension,Repository,SecurityState,Settings,Title,WatchProgress} from '../core/types.js';
import {decryptBytes,decryptRecord,encryptBytes,encryptRecord,generateDataKey,generateWrappingKey,hashPin,sha256Hex,unwrapDataKeyWithKey,unwrapDataKeyWithPassword,verifyPin,wrapDataKeyWithKey,wrapDataKeyWithPassword} from '../security/crypto.js';

const DB='cloudstream-2-web', VERSION=3;
const SECURE=['bookmarks','progress','history','collections','downloads','settings','extensions','searches','security','repositories'];
const LEGACY=['titles','bookmarks','progress','history','collections','downloads','repositories','settings'];

type Bootstrap={version:2;mode:'install'|'pin';installKey:CryptoKey;wrapped:{version:2;algorithm:'AES-GCM';iv:string;wrapped:string}|{version:2;algorithm:'AES-GCM';salt:string;iv:string;wrapped:string};pinConfigured:boolean;pinVerifier?:{salt:string;hash:string;iterations:number};lockOnHidden:boolean;keyVersion:number;needsPinRewrap?:boolean};
let dbp:Promise<IDBDatabase>|undefined;let dataKey:CryptoKey|undefined;let bootstrap:Bootstrap|undefined;

function request<T>(r:IDBRequest<T>):Promise<T>{return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function txDone(tx:IDBTransaction):Promise<void>{return new Promise((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error??new Error('Transaction aborted'));});}
function open(){if(dbp)return dbp;dbp=new Promise((resolve,reject)=>{const r=indexedDB.open(DB,VERSION);r.onupgradeneeded=()=>{const d=r.result;for(const s of LEGACY){if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:s==='settings'?'key':'key'});}if(!d.objectStoreNames.contains('secure'))d.createObjectStore('secure',{keyPath:'key'});if(!d.objectStoreNames.contains('extensions'))d.createObjectStore('extensions',{keyPath:'key'});if(!d.objectStoreNames.contains('meta'))d.createObjectStore('meta',{keyPath:'key'});if(!d.objectStoreNames.contains('downloadChunks'))d.createObjectStore('downloadChunks',{keyPath:'key'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});return dbp;}
async function getMeta<T>(key:string){const d=await open();return request(d.transaction('meta').objectStore('meta').get(key)) as Promise<T|undefined>}
async function putMeta<T>(key:string,value:T){const d=await open();const tx=d.transaction('meta','readwrite');tx.objectStore('meta').put({key,value});await txDone(tx);}
async function deleteMeta(key:string){const d=await open();const tx=d.transaction('meta','readwrite');tx.objectStore('meta').delete(key);await txDone(tx);}
async function allFrom(store:string){const d=await open();return request<any[]>(d.transaction(store).objectStore(store).getAll());}
async function txClear(store:string){const d=await open();const tx=d.transaction(store,'readwrite');tx.objectStore(store).clear();await txDone(tx);}

export class StorageLockedError extends Error { constructor(){super('Local data is locked. Unlock the app first.');this.name='StorageLockedError';} }
async function requireKey(){if(!dataKey)throw new StorageLockedError();return dataKey;}
async function secureAllRaw(){const d=await open();return request<any[]>(d.transaction('secure').objectStore('secure').getAll());}

async function encryptAllWithKey(key:CryptoKey, values:any[]){const d=await open();const tx=d.transaction('secure','readwrite');const os=tx.objectStore('secure');os.clear();for(const v of values){const packed=await encryptRecord(v.value,key);os.put({key:v.key,store:v.store,recordKey:v.recordKey,...packed});}await txDone(tx);}

async function migrateLegacy(oldKey:CryptoKey|undefined){
  const rows=await secureAllRaw();
  const values:any[]=[];
  if(oldKey){for(const r of rows){try{values.push({key:r.key,store:r.store,recordKey:r.recordKey,value:await decryptRecord({iv:r.iv,cipher:r.cipher},oldKey)});}catch{}}}
  const legacyCandidates=['bookmarks','progress','history','collections','downloads','settings','extensions','searches','security','repositories'];
  for(const store of legacyCandidates){try{const old=await allFrom(store);for(const v of old){if(v&&typeof v==='object'){const key=store==='settings'?'settings':String(v.key??v.id??crypto.randomUUID());values.push({key:`${store}:${key}`,store,recordKey:key,value:v});}}}catch{}}
  return values;
}

async function setupBootstrap(){
  bootstrap=await getMeta<Bootstrap>('crypto-bootstrap');
  if(bootstrap){
    if(bootstrap.mode==='install')dataKey=await unwrapDataKeyWithKey(bootstrap.wrapped as any,bootstrap.installKey);
    return;
  }
  const legacy=await getMeta<any>('data-key');
  const oldKey=legacy?.localKey as CryptoKey|undefined;
  const legacyValues=await migrateLegacy(oldKey);
  const newKey=await generateDataKey();
  const installKey=await generateWrappingKey();
  const wrapped=await wrapDataKeyWithKey(newKey,installKey);
  const pinVerifier=legacyValues.find(x=>x.store==='security'&&x.recordKey==='pin')?.value;
  bootstrap={version:2,mode:'install',installKey,wrapped,pinConfigured:false,lockOnHidden:true,keyVersion:2};
  if(pinVerifier&&pinVerifier.salt&&pinVerifier.hash){bootstrap.pinVerifier=undefined;bootstrap.pinConfigured=false;bootstrap.needsPinRewrap=true;}
  await putMeta('crypto-bootstrap',bootstrap);await deleteMeta('data-key');dataKey=newKey;await encryptAllWithKey(newKey,legacyValues);for(const s of LEGACY){try{await txClear(s)}catch{}}
}

export async function initializeStorage(){await open();await setupBootstrap();}
export async function isStorageLocked(){const b=await getMeta<Bootstrap>('crypto-bootstrap');return Boolean(b?.mode==='pin'&&!dataKey);}
export async function unlockStorage(pin:string){const b=await getMeta<Bootstrap>('crypto-bootstrap');if(!b)throw new Error('Storage is not initialized.');if(b.mode!=='pin'){dataKey=await unwrapDataKeyWithKey(b.wrapped as any,b.installKey);return true;}if(!b.pinVerifier||!(await verifyPin(pin,b.pinVerifier)))return false;dataKey=await unwrapDataKeyWithPassword(b.wrapped as any,pin);bootstrap=b;return true;}
export async function lockStorage(){dataKey=undefined;}
export async function setPin(pin:string){if(!/^\d{4,8}$/.test(pin))throw new Error('PIN must contain 4–8 digits.');const key=await requireKey();const b=await getMeta<Bootstrap>('crypto-bootstrap');if(!b)throw new Error('Storage is not initialized.');const verifier=await hashPin(pin);b.mode='pin';b.wrapped=await wrapDataKeyWithPassword(key,pin);b.pinVerifier=verifier;b.pinConfigured=true;b.needsPinRewrap=false;await putMeta('crypto-bootstrap',b);bootstrap=b;}
export async function removePin(){const key=await requireKey();const b=await getMeta<Bootstrap>('crypto-bootstrap');if(!b)return;b.mode='install';b.wrapped=await wrapDataKeyWithKey(key,b.installKey);b.pinConfigured=false;b.pinVerifier=undefined;b.needsPinRewrap=false;await putMeta('crypto-bootstrap',b);bootstrap=b;}
export async function hasPin(){const b=await getMeta<Bootstrap>('crypto-bootstrap');return Boolean(b?.pinConfigured);}
export async function verifyStoredPin(pin:string){const b=await getMeta<Bootstrap>('crypto-bootstrap');return Boolean(b?.pinVerifier&&await verifyPin(pin,b.pinVerifier));}
export async function getSecurityState():Promise<SecurityState>{const b=await getMeta<Bootstrap>('crypto-bootstrap');return {pinConfigured:Boolean(b?.pinConfigured),lockOnHidden:b?.lockOnHidden??true,dataKeyWrapped:Boolean(b),keyVersion:b?.keyVersion??2};}
export async function saveSecurityState(state:SecurityState){const b=await getMeta<Bootstrap>('crypto-bootstrap');if(!b)throw new Error('Storage is not initialized.');b.lockOnHidden=Boolean(state.lockOnHidden);b.pinConfigured=state.pinConfigured;await putMeta('crypto-bootstrap',b);bootstrap=b;}

export async function securePut(store:string,key:string,value:unknown){if(!SECURE.includes(store))throw new Error(`Store ${store} is not encrypted.`);const k=await requireKey();const packed=await encryptRecord(value,k);const d=await open();const tx=d.transaction('secure','readwrite');tx.objectStore('secure').put({key:`${store}:${key}`,store,recordKey:key,...packed});await txDone(tx);}
export async function secureGet<T>(store:string,key:string){const d=await open();const r=await request<any>(d.transaction('secure').objectStore('secure').get(`${store}:${key}`));if(!r)return undefined;return decryptRecord<T>({iv:r.iv,cipher:r.cipher},await requireKey());}
export async function secureAll<T>(store:string){const rows=(await secureAllRaw()).filter(x=>x.store===store);const k=await requireKey();const out:T[]=[];for(const r of rows)out.push(await decryptRecord<T>({iv:r.iv,cipher:r.cipher},k));return out;}
export async function secureRemove(store:string,key:string){const d=await open();const tx=d.transaction('secure','readwrite');tx.objectStore('secure').delete(`${store}:${key}`);await txDone(tx);}
export async function secureClear(store:string){const d=await open();const tx=d.transaction('secure','readwrite');const os=tx.objectStore('secure');for(const r of (await request<any[]>(os.getAll())).filter(x=>x.store===store))os.delete(r.key);await txDone(tx);}

export async function putTitle(title:Title){const d=await open();const tx=d.transaction('titles','readwrite');tx.objectStore('titles').put({...title,key:title.id});await txDone(tx);}
export async function getTitle<T=Title>(key:string){const d=await open();return request(d.transaction('titles').objectStore('titles').get(key)) as Promise<T|undefined>;}
export async function allTitles<T=Title>(){const d=await open();return request(d.transaction('titles').objectStore('titles').getAll()) as Promise<T[]>;}
export async function clearTitles(){return txClear('titles');}
export async function saveRepository(repo:Repository){await securePut('repositories',repo.url,repo);}
export async function getRepositories(){return secureAll<Repository>('repositories');}
export async function deleteRepository(url:string){await secureRemove('repositories',url);}
export async function saveExtension(ext:InstalledExtension){await securePut('extensions',ext.manifest.id,ext);}
export async function getExtensions(){return secureAll<InstalledExtension>('extensions');}
export async function deleteExtension(id:string){await secureRemove('extensions',id);}
export async function getSettings(defaults:Settings){const saved=await secureGet<Partial<Settings>>('settings','settings');return {...defaults,...(saved??{})};}
export async function saveSettings(settings:Settings){await securePut('settings','settings',settings);}
export async function allSecure<T=unknown>(store:string){return secureAll<T>(store);}
export async function putSecure(store:string,key:string,value:unknown){return securePut(store,key,value);}
export async function getSecure<T>(store:string,key:string){return secureGet<T>(store,key);}
export async function removeSecure(store:string,key:string){return secureRemove(store,key);}
export async function clearStore(store:string){if(store==='titles')return txClear(store);return secureClear(store);}

export async function seedDemo(){const existing=await getTitle('demo-1');if(existing)return;await putTitle({id:'demo-1',providerId:'demo',type:'movie',title:'Open Media Demo',originalTitle:'Open Media Demo',year:2025,genres:['Drama','Indie'],rating:8.1,runtimeMinutes:107,language:'English',country:'Global',overview:'A local-first demonstration item. Playback uses a user-provided authorized HTTPS media source.',poster:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80',backdrop:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1600&q=80'});}
export async function putDownloadChunk(jobId:string,index:number,chunk:ArrayBuffer){const digest=await sha256Hex(chunk);const packed=await encryptBytes(chunk,await requireKey());const d=await open();const tx=d.transaction('downloadChunks','readwrite');tx.objectStore('downloadChunks').put({key:`${jobId}:${index}`,jobId,index,iv:packed.iv,cipher:packed.cipher,sha256:digest});await txDone(tx);}
export async function getDownloadChunks(jobId:string){const d=await open();const rows=await request<any[]>(d.transaction('downloadChunks').objectStore('downloadChunks').getAll());const key=await requireKey();const out:ArrayBuffer[]=[];for(const x of rows.filter(r=>r.jobId===jobId).sort((a,b)=>a.index-b.index)){const bytes=x.iv&&x.cipher?await decryptBytes({iv:x.iv,cipher:x.cipher},key):x.chunk as ArrayBuffer;if(x.sha256 && (await sha256Hex(bytes))!==x.sha256)throw new Error('Downloaded chunk integrity check failed.');out.push(bytes);}return out;}
export async function clearDownloadChunks(jobId:string){const d=await open();const tx=d.transaction('downloadChunks','readwrite');const os=tx.objectStore('downloadChunks');for(const r of (await request<any[]>(os.getAll())).filter(x=>x.jobId===jobId))os.delete(r.key);await txDone(tx);}
export async function wipeAll(){
  dataKey=undefined;bootstrap=undefined;dbp=undefined;
  const d=await open();for(const s of [...LEGACY,'secure','meta','downloadChunks']){if(d.objectStoreNames.contains(s)){try{await txClear(s)}catch{}}}
  dataKey=undefined;await setupBootstrap();
}
