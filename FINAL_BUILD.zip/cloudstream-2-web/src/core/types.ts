export type MediaType = 'movie' | 'series' | 'anime' | 'tv';
export type Theme = 'amoled' | 'dark' | 'dim' | 'light' | 'system';
export type TrustState = 'Trusted' | 'Verified' | 'Unverified' | 'Blocked';
export type ProviderStatus = 'online' | 'slow' | 'offline' | 'incompatible' | 'unknown';
export type Capability = 'search' | 'metadata' | 'sources' | 'subtitles' | 'home';
export type Permission = Capability | 'network' | 'storage';
export type QualityLabel = '4K' | '1080p' | '720p' | '480p' | '360p' | 'Auto';

export interface CastMember { id?: string; name: string; role?: string; character?: string; photo?: string; }
export interface CrewMember { id?: string; name: string; job?: string; department?: string; }
export interface Subtitle { id: string; url: string; language: string; label?: string; mime?: string; forced?: boolean; default?: boolean; }
export interface AudioTrack { id: string; label: string; language?: string; mime?: string; }
export interface Source { id: string; providerId: string; url: string; title: string; quality: QualityLabel; mime?: string; bitrate?: number; sizeBytes?: number; headers?: Record<string,string>; downloadable?: boolean; }
export interface Episode { id: string; titleKey: string; season: number; episode: number; name: string; overview?: string; runtimeMinutes?: number; airDate?: string; thumbnail?: string; watched?: boolean; }
export interface Season { number: number; name?: string; episodes: Episode[]; }
export interface Title {
  id: string; providerId: string; type: MediaType; title: string; originalTitle?: string; year?: number; genres: string[];
  rating?: number; runtimeMinutes?: number; language?: string; country?: string; overview: string;
  poster?: string; backdrop?: string; trailerUrl?: string; intro?: {start:number; end:number}; outroStart?: number; cast?: CastMember[]; crew?: CrewMember[];
  seasons?: Season[]; tags?: string[];
}
export interface SearchResult { title: Title; sourceCount: number; providerId: string; score?: number; }
export interface EpisodeContext { season:number; episode:number; episodeId?:string; }
export interface ProviderContext { signal: AbortSignal; fetchJson<T>(url: string, init?: RequestInit): Promise<T>; }
export interface Provider {
  id: string; name: string; version: string; capabilities: Capability[]; trust: TrustState; status?: ProviderStatus; description?: string;
  search(q: string, ctx: ProviderContext): Promise<SearchResult[]>;
  getMetadata?(title: Title, ctx: ProviderContext): Promise<Title>;
  getSources?(title: Title, ctx: ProviderContext, episode?: EpisodeContext): Promise<Source[]>;
  getSubtitles?(title: Title, ctx: ProviderContext, episode?: EpisodeContext): Promise<Subtitle[]>;
  getHome?(ctx: ProviderContext): Promise<SearchResult[]>;
}
export interface Repository { url: string; name: string; description?: string; manifestVersion: number; pluginLists: string[]; trust: TrustState; updatedAt: number; cacheExpiresAt: number; lastError?: string; pluginCache?: WebExtensionManifest[]; }
export interface WebExtensionManifest {
  manifestVersion: 1; id: string; name: string; version: string; description: string; author: string; homepage?: string;
  capabilities: Capability[]; permissions: Permission[]; origins: string[]; dependencies?: string[]; sha256?: string; publisher?: { name: string; keyId?: string; publicKey?: string; signature?: string };
  provider: { search?: EndpointSpec; metadata?: EndpointSpec; sources?: EndpointSpec; subtitles?: EndpointSpec; home?: EndpointSpec };
}
export interface EndpointSpec { method?: 'GET' | 'POST'; url: string; query?: Record<string,string>; headers?: Record<string,string>; body?: unknown; responsePath?: string; resultMap?: Record<string,string>; }
export interface InstalledExtension { manifest: WebExtensionManifest; enabled: boolean; installedAt: number; repositoryUrl: string; status: ProviderStatus; latestVersion?: string; }
export interface Bookmark { key:string; title:Title; createdAt:number; kind:'bookmark'|'watchlist'; }
export interface WatchProgress { key:string; titleKey:string; season?:number; episode?:number; timestamp:number; duration:number; percentage:number; providerId?:string; updatedAt:number; }
export interface HistoryItem { key:string; titleKey:string; playedAt:number; }
export interface Collection { id:string; name:string; titleKeys:string[]; createdAt:number; updatedAt:number; }
export interface DownloadJob { id:string; source:Source; title:Title; status:'queued'|'downloading'|'paused'|'completed'|'failed'|'cancelled'; bytesReceived:number; totalBytes?:number; createdAt:number; updatedAt:number; error?:string; localChunks?:number; }
export interface Settings { demoSourceUrl?:string; theme:Theme; accent:string; historyRetentionDays:number; autoLockMinutes:number; autoplay:boolean; completionThreshold:number; defaultSubtitleLanguage:string; reducedMotion:boolean; density:'compact'|'comfortable'; repositoryRefreshHours:number; }
export interface SecurityState { pinConfigured:boolean; lockOnHidden:boolean; dataKeyWrapped:boolean; keyVersion:number; }
export interface BackupPayload { schemaVersion:number; exportedAt:number; records: Record<string,unknown[]>; }
export interface NormalizedRepositoryResponse { name?: string; description?: string; manifestVersion?: number; pluginLists?: string[]; }
