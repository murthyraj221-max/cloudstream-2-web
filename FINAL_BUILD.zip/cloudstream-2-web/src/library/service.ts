import type {Bookmark,Collection,Title,WatchProgress} from '../core/types.js';
import {allSecure,allTitles,getSecure,putSecure,removeSecure} from '../storage/db.js';
export async function listBookmarks(kind:'bookmark'|'watchlist'='bookmark'){return (await allSecure<Bookmark>('bookmarks')).filter(x=>x.kind===kind);}
export async function toggleBookmark(title:Title,kind:'bookmark'|'watchlist'='bookmark'){const key=`${kind}:${title.id}`;const existing=await getSecure<Bookmark>('bookmarks',key);if(existing){await removeSecure('bookmarks',key);return false;}await putSecure('bookmarks',key,{key,title,createdAt:Date.now(),kind});return true;}
export async function setWatched(title:Title,watched:boolean,season?:number,episode?:number){const key=`progress:${title.id}:${season??0}:${episode??0}`;const duration=(title.runtimeMinutes??0)*60;await putSecure('progress',key,{key,titleKey:title.id,season,episode,timestamp:watched?duration:0,duration,percentage:watched?100:0,updatedAt:Date.now(),providerId:title.providerId} satisfies WatchProgress);}
export async function listProgress(){return allSecure<WatchProgress>('progress');}
export async function listCollections(){return allSecure<Collection>('collections');}
export async function createCollection(name:string){const c:Collection={id:crypto.randomUUID(),name:name.trim().slice(0,80),titleKeys:[],createdAt:Date.now(),updatedAt:Date.now()};await putSecure('collections',c.id,c);return c;}
export async function updateCollection(c:Collection){c.updatedAt=Date.now();await putSecure('collections',c.id,c);}
export async function deleteCollection(id:string){await removeSecure('collections',id);}
export async function addToCollection(id:string,titleId:string){const c=await getSecure<Collection>('collections',id);if(!c)return; if(!c.titleKeys.includes(titleId))c.titleKeys.push(titleId);await updateCollection(c);}
export async function removeFromCollection(id:string,titleId:string){const c=await getSecure<Collection>('collections',id);if(!c)return;c.titleKeys=c.titleKeys.filter(x=>x!==titleId);await updateCollection(c);}
export async function titleMap(){const ts=await allTitles<Title>();return new Map(ts.map(t=>[t.id,t]));}
