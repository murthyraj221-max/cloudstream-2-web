import type {Settings} from '../core/types.js';
import {getSettings,saveSettings} from '../storage/db.js';
export const DEFAULT_SETTINGS:Settings={demoSourceUrl:undefined,theme:'amoled',accent:'#e8e8e8',historyRetentionDays:90,autoLockMinutes:0,autoplay:true,completionThreshold:0.9,defaultSubtitleLanguage:'en',reducedMotion:false,density:'comfortable',repositoryRefreshHours:24};
export async function loadSettings(){return getSettings(DEFAULT_SETTINGS);}
export async function updateSettings(patch:Partial<Settings>){const current=await loadSettings();const next={...current,...patch};await saveSettings(next);return next;}
