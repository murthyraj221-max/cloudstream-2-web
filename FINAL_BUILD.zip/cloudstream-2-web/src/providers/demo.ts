import type {Provider,ProviderContext,SearchResult,Source,Subtitle,Title} from '../core/types.js';
import {validateHttpUrl} from '../security/validation.js';
import {putTitle, getSettings} from '../storage/db.js';

const catalog:Title[]=[
 {id:'demo-1',providerId:'demo',type:'movie',title:'Open Media Demo',originalTitle:'Open Media Demo',year:2025,genres:['Drama','Indie'],rating:8.1,runtimeMinutes:107,language:'English',country:'Global',overview:'A safe demonstration item. Configure an authorized HTTPS MP4/WebM URL in Settings to play it.',poster:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80',backdrop:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1600&q=80'}
];
for(const t of catalog)void putTitle(t).catch(()=>{});
export const demoProvider:Provider={
 id:'demo',name:'Local Demo Provider',version:'1.0.0',capabilities:['search','metadata','sources','subtitles','home'],trust:'Trusted',status:'online',description:'Local provider used to exercise the browser-native architecture.',
 async search(q,_ctx){const n=q.trim().toLowerCase();return (n?catalog.filter(x=>x.title.toLowerCase().includes(n)||x.genres.some(g=>g.toLowerCase().includes(n))):catalog).map(title=>({title,sourceCount:1,providerId:'demo',score:n?1:0.5}));},
 async getMetadata(title){return catalog.find(x=>x.id===title.id)??title;},
 async getSources(_title){const saved=(await getSettings({demoSourceUrl:undefined,theme:'amoled',accent:'#e8e8e8',historyRetentionDays:90,autoLockMinutes:0,autoplay:true,completionThreshold:.9,defaultSubtitleLanguage:'en',reducedMotion:false,density:'comfortable',repositoryRefreshHours:24})).demoSourceUrl;if(!saved)return [];try{const u=validateHttpUrl(saved);return [{id:'demo-src',providerId:'demo',url:u.toString(),title:'User-authorized source',quality:'Auto',mime:/\.webm(?:$|\?)/i.test(u.pathname)?'video/webm':'video/mp4',downloadable:true} as Source];}catch{return []; }},
 async getSubtitles(){return [] as Subtitle[];},
 async getHome(){return catalog.map(title=>({title,sourceCount:1,providerId:'demo',score:0.5}));}
};
export const demoContext=(signal:AbortSignal):ProviderContext=>({signal,fetchJson:async()=>{throw new Error('Demo provider does not use network.');}});
