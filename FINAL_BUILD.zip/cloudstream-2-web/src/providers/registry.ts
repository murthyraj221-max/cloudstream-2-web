import type {Provider} from '../core/types.js';
import {demoProvider} from './demo.js';
import {listInstalled} from '../extensions/manager.js';
import {createProvider,ExtensionRuntime} from '../extensions/runtime.js';
const runtimeProviders=new Map<string,{version:string;provider:Provider}>();
export async function getProviders():Promise<Provider[]>{const installed=await listInstalled();const activeIds=new Set(installed.filter(x=>x.enabled).map(x=>x.manifest.id));for(const [id] of runtimeProviders)if(!activeIds.has(id))runtimeProviders.delete(id);const result:Provider[]=[demoProvider];for(const x of installed.filter(x=>x.enabled)){const prev=runtimeProviders.get(x.manifest.id);if(prev?.version===x.manifest.version){result.push(prev.provider);continue;}const provider=createProvider(x.manifest);runtimeProviders.set(x.manifest.id,{version:x.manifest.version,provider});result.push(provider);}return result;}
