import test from 'node:test';
import assert from 'node:assert/strict';
import {validateHttpUrl, compareVersions, validateEndpointUrl} from '../dist/assets/security/validation.js';
import {validateManifest} from '../dist/assets/extensions/manifest.js';
import {encryptJson,decryptJson,hashPin,verifyPin,sha256Hex,canonicalize} from '../dist/assets/security/crypto.js';
import {searchProviders} from '../dist/assets/search/engine.js';

const manifest={manifestVersion:1,id:'example.web',name:'Example Web Provider',version:'1.2.3',description:'Test provider',author:'Test',capabilities:['search','metadata','sources','subtitles'],permissions:['network','search','metadata','sources','subtitles'],origins:['https://example.test'],provider:{search:{url:'https://example.test/search?q={q}',method:'GET',responsePath:'results',resultMap:{id:'id',title:'title'}},metadata:{url:'https://example.test/item/{id}',method:'GET',resultMap:{id:'id',title:'title'}},sources:{url:'https://example.test/item/{id}/sources',method:'GET',responsePath:'sources',resultMap:{id:'id',title:'title',url:'url',quality:'quality'}},subtitles:{url:'https://example.test/item/{id}/subs',method:'GET',responsePath:'subs',resultMap:{id:'id',language:'language',url:'url'}}}};

test('URL validation blocks insecure/private endpoints',()=>{
  assert.throws(()=>validateHttpUrl('http://example.com'));
  assert.throws(()=>validateHttpUrl('https://localhost/a'));
  assert.throws(()=>validateHttpUrl('https://127.0.0.1/a'));
  assert.throws(()=>validateHttpUrl('https://10.0.0.1/a'));
  assert.throws(()=>validateHttpUrl('https://172.16.0.1/a'));
  assert.throws(()=>validateHttpUrl('https://192.168.1.2/a'));
  assert.throws(()=>validateHttpUrl('https://[::1]/a'));
  assert.throws(()=>validateHttpUrl('https://example.com:8443/a'));
  assert.throws(()=>validateHttpUrl('https://user:pass@example.com/a'));
  assert.equal(validateHttpUrl('https://example.com/a').hostname,'example.com');
});

test('endpoint validation respects manifest origin allowlist',()=>{
  assert.equal(validateEndpointUrl('https://example.test/a',manifest.origins).hostname,'example.test');
  assert.throws(()=>validateEndpointUrl('https://evil.test/a',manifest.origins));
});

test('manifest validation rejects malformed capability/permission combinations',()=>{
  assert.equal(validateManifest(manifest).id,'example.web');
  assert.throws(()=>validateManifest({...manifest,id:'Bad ID'}));
  assert.throws(()=>validateManifest({...manifest,capabilities:['search'],permissions:['network','sources']}));
  assert.throws(()=>validateManifest({...manifest,origins:['http://example.test']}));
});

test('version comparison works',()=>{
  assert(compareVersions('2.0.0','1.9.9')>0);
  assert(compareVersions('1.0.0','1.0.0')===0);
  assert(compareVersions('1.0.0','1.0.1')<0);
});

test('AES-GCM backup encryption round trips and rejects tampering',async()=>{
  const payload={hello:'world',records:[1,2,3]};
  const packed=await encryptJson(payload,'correct horse battery staple');
  assert.deepEqual(await decryptJson(packed,'correct horse battery staple'),payload);
  await assert.rejects(()=>decryptJson(packed,'wrong password'));
  const obj=JSON.parse(packed); obj.cipher=obj.cipher.slice(0,-2)+'aa';
  await assert.rejects(()=>decryptJson(JSON.stringify(obj),'correct horse battery staple'));
});

test('PIN is salted and verifiable without storing plaintext',async()=>{
  const one=await hashPin('1234');
  const two=await hashPin('1234');
  assert.notEqual(one.salt,two.salt);
  assert.notEqual(one.hash,two.hash);
  assert.equal(await verifyPin('1234',one),true);
  assert.equal(await verifyPin('9999',one),false);
  assert.match(JSON.stringify(one),/salt/);
  assert.doesNotMatch(JSON.stringify(one),/1234/);
});

test('canonical hashing is deterministic',async()=>{
  const a={b:2,a:1}; const b={a:1,b:2};
  assert.equal(canonicalize(a),canonicalize(b));
  assert.equal(await sha256Hex(canonicalize(a)),await sha256Hex(canonicalize(b)));
});

test('search engine isolates provider failures, deduplicates and filters',async()=>{
  const good={id:'good',name:'Good',version:'1',capabilities:['search'],search:async()=>[
    {providerId:'good',title:{id:'g1',providerId:'good',type:'movie',title:'Alpha',year:2024,genres:['Drama'],overview:'',language:'English',poster:'https://example.test/a'}},
    {providerId:'good',title:{id:'g2',providerId:'good',type:'movie',title:'Alpha',year:2024,genres:['Drama'],overview:'',language:'English',poster:'https://example.test/a'}},
  ]};
  const bad={id:'bad',name:'Bad',version:'1',capabilities:['search'],search:async()=>{throw new Error('down');}};
  const r=await searchProviders('Alpha',[good,bad],new AbortController().signal,{language:'English'});
  assert.equal(r.results.length,1);
  assert.equal(r.failures.length,1);
  assert.equal(r.results[0].title.title,'Alpha');
});

test('DEK can be re-wrapped to a new PIN without re-encrypting records',async()=>{
  const {generateDataKey,wrapDataKeyWithPassword,unwrapDataKeyWithPassword,encryptRecord,decryptRecord,encryptBytes,decryptBytes}=await import('../dist/assets/security/crypto.js');
  const key=await generateDataKey();
  const first=await wrapDataKeyWithPassword(key,'1234');
  const opened=await unwrapDataKeyWithPassword(first,'1234');
  const second=await wrapDataKeyWithPassword(opened,'5678');
  await assert.rejects(()=>unwrapDataKeyWithPassword(second,'1234'));
  const reopened=await unwrapDataKeyWithPassword(second,'5678');
  const packed=await encryptRecord({private:'value'},reopened);
  assert.deepEqual(await decryptRecord(packed,reopened),{private:'value'});
  const bytes=new TextEncoder().encode('private media chunk');
  const packedBytes=await encryptBytes(bytes.buffer,reopened);
  assert.equal(new TextDecoder().decode(await decryptBytes(packedBytes,reopened)),'private media chunk');
});

test('XSS escaping converts dangerous metadata into inert text',async()=>{
  const {escapeHtml,stripUnsafeSubtitleMarkup}=await import('../dist/assets/security/sanitize.js');
  const payload='<script>alert(1)</script><img src=x onerror=alert(2)><a href="javascript:alert(3)">x</a>';
  assert.match(escapeHtml(payload),/&lt;script&gt;/i);
  assert.doesNotMatch(escapeHtml(payload),/<script>/i);
  assert.doesNotMatch(stripUnsafeSubtitleMarkup(payload),/<(?:script|img|a)/i);
  assert.doesNotMatch(stripUnsafeSubtitleMarkup(payload),/javascript:/i);
});
