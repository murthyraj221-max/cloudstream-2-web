import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {validateHttpUrl} from '../dist/assets/security/validation.js';
import {generateDataKey,generateWrappingKey,wrapDataKeyWithPassword,unwrapDataKeyWithPassword} from '../dist/assets/security/crypto.js';
import {validateManifest} from '../dist/assets/extensions/manifest.js';

const ROOT='.';
const worker=await readFile('src/extensions/runtime-worker.ts','utf8');
const main=await readFile('src/app/main.ts','utf8');
const sw=await readFile('public/sw.js','utf8');

test('remote code execution primitives are absent',()=>{
  for(const token of ['eval(','new Function(','<script src=','javascript:']){
    assert.equal(worker.includes(token),false,`worker contains ${token}`);
    assert.equal(main.includes(token),false,`main contains ${token}`);
  }
});

test('repository URL attack cases are rejected',()=>{
  for(const url of [
    'http://evil.test/repo.json',
    'https://localhost/repo.json',
    'https://127.0.0.1/repo.json',
    'https://0.0.0.0/repo.json',
    'https://10.1.2.3/repo.json',
    'https://172.20.1.1/repo.json',
    'https://192.168.10.10/repo.json',
    'https://169.254.169.254/repo.json',
    'https://[::1]/repo.json',
    'https://[fe80::1]/repo.json',
    'https://[fc00::1]/repo.json',
    'https://[fd12:3456::1]/repo.json',
    'https://[::ffff:10.1.2.3]/repo.json',
    'https://evil.test:8443/repo.json',
  ]) assert.throws(()=>validateHttpUrl(url),url);
});

test('manifest rejects dangerous origins and malformed data',()=>{
  const base={manifestVersion:1,id:'safe.web',name:'Safe',version:'1.0.0',description:'x',author:'x',capabilities:['search'],permissions:['search','network'],origins:['https://safe.test'],provider:{search:{url:'https://safe.test/search?q={q}',method:'GET'}}};
  assert.doesNotThrow(()=>validateManifest(base));
  assert.throws(()=>validateManifest({...base,origins:['https://localhost']}));
  assert.throws(()=>validateManifest({...base,provider:{search:{url:'http://safe.test/search',method:'GET'}}}));
  assert.throws(()=>validateManifest({...base,capabilities:['camera']}));
});

test('service worker stays same-origin and avoids arbitrary media caching',()=>{
  assert.match(sw,/u\.origin!==self\.location\.origin/);
  assert.match(sw,/\/assets|\/icons/);
  assert.doesNotMatch(sw,/caches\.put\(e\.request,copy\)/);
  assert.match(sw,/GET/);
});


test('application data key is password-wrappable and wrong password cannot unwrap it',async()=>{const dek=await generateDataKey();const wrapped=await wrapDataKeyWithPassword(dek,'123456');const same=await unwrapDataKeyWithPassword(wrapped,'123456');const probe=new TextEncoder().encode('probe');const iv=crypto.getRandomValues(new Uint8Array(12));const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},dek,probe);const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv},same,cipher);assert.equal(new TextDecoder().decode(plain),'probe');await assert.rejects(()=>unwrapDataKeyWithPassword(wrapped,'999999'));});

test('production sources do not contain executable remote-code or inline-style primitives',async()=>{const {readdir}=await import('node:fs/promises');const all=await readdir('src',{recursive:true});for(const f of all.filter(x=>String(x).endsWith('.ts'))){const text=await readFile('src/'+f,'utf8');assert.doesNotMatch(text,/eval\s*\(|new Function\s*\(|<script\s+src=/i);assert.doesNotMatch(text,/style\s*=\s*['\"]/i);}});

test('CSP and production source have no unsafe-inline or remote script execution primitives',async()=>{
  const h=await readFile(path.join(ROOT,'_headers'),'utf8');
  assert.match(h,/Content-Security-Policy:/);
  assert.doesNotMatch(h,/unsafe-inline/);
  assert.match(h,/script-src 'self'/);
  const html=await readFile(path.join(ROOT,'index.html'),'utf8');
  assert.doesNotMatch(html,/<script[^>]+src=["']https?:/i);
});


test('self-declared extension hashes/signatures never become trusted automatically',async()=>{const {manifestTrustState}=await import('../dist/assets/extensions/manifest.js');const manifest={manifestVersion:1,id:'safe.web',name:'Safe',version:'1.0.0',description:'x',author:'x',capabilities:['search'],permissions:['search','network'],origins:['https://safe.test'],sha256:'a'.repeat(64),publisher:{publicKey:'x',signature:'y'},provider:{search:{url:'https://safe.test/search?q={q}',method:'GET'}}};assert.equal(manifestTrustState(manifest),'Unverified');});
