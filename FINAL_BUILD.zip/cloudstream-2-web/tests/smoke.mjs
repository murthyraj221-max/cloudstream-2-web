import {readFile} from 'node:fs/promises';
import {access} from 'node:fs/promises';
const must=['dist/index.html','dist/manifest.webmanifest','dist/sw.js','dist/assets/app/main.js','dist/assets/styles.css','dist/assets/extensions/runtime.js','dist/assets/extensions/runtime-worker.js'];
for(const f of must){await access(f);const s=await readFile(f,'utf8');if(!s.length)throw new Error(`${f} empty`);}
const html=await readFile('dist/index.html','utf8');for(const token of ['/assets/app/main.js','/assets/styles.css','/manifest.webmanifest'])if(!html.includes(token))throw new Error(`Missing ${token}`);
const manifest=JSON.parse(await readFile('dist/manifest.webmanifest','utf8'));if(manifest.display!=='standalone')throw new Error('PWA display mode missing');
if(!html.includes('viewport-fit=cover'))throw new Error('Mobile safe-area viewport missing');
console.log('Artifact smoke tests passed');
