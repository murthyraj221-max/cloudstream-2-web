import {defineConfig} from 'vite';
export default defineConfig({
  build:{target:'es2022',sourcemap:false,rollupOptions:{output:{entryFileNames:'assets/[name].js',chunkFileNames:'assets/[name]-[hash].js',assetFileNames:'assets/[name][extname]'}}},
  server:{host:'0.0.0.0',port:4173},
  preview:{host:'0.0.0.0',port:4173}
});
