const VERSION='cs2-web-v3';
const STATIC=`${VERSION}-static`;
const ASSETS=['/','/index.html','/assets/styles.css','/assets/app/main.js','/manifest.webmanifest','/robots.txt','/icons/icon-192.svg','/icons/icon-512.svg'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(STATIC).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('cs2-web-')&&k!==STATIC).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{const req=event.request;const u=new URL(req.url);if(u.origin!==self.location.origin||req.method!=='GET')return;const isShell=u.pathname==='/'||u.pathname==='/index.html'||u.pathname.startsWith('/assets/')||u.pathname.startsWith('/icons/')||u.pathname==='/manifest.webmanifest'||u.pathname==='/robots.txt';if(!isShell)return;event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{if(res.ok&&res.type==='basic'){const copy=res.clone();void caches.open(STATIC).then(c=>c.put(req,copy));}return res;}).catch(()=>caches.match('/index.html'))));});
