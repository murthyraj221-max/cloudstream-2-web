# CloudStream 2.0 Web

CloudStream 2.0 Web is an original, browser-first, privacy-first media-center PWA inspired by CloudStream's extension-centric workflow. It is **not the official CloudStream application** and does not bundle copyrighted media or unauthorized streaming sources.

## Legal disclaimer

> We do not provide, host, or distribute extensions or any unauthorized or illegal video content.
>
> The application is a media-center platform. Users are responsible for ensuring that sources they configure and content they access are authorized.

## Architecture

The app is intentionally web-native:

```text
UI -> typed services -> IndexedDB/Web Crypto
                   -> Provider Registry
                   -> Declarative WebExtension Worker runtime
                   -> HTML5 media player / authorized downloads
```

See `docs/cloudstream-architecture-notes.md` for the source comparison and design decisions.

## Important extension compatibility note

The official CloudStream ecosystem contains native `.cs3` plugins. Browsers must not execute arbitrary native/plugin JavaScript downloaded from a remote repository. This project therefore accepts a safer declarative web-provider manifest with explicit HTTPS origins, capabilities and permissions. Native `.cs3` entries are recognized as unsupported and are not executed.

A web provider can expose JSON endpoints for:

- search
- metadata
- sources
- subtitles
- home

The runtime executes those calls from a module Worker with request validation, timeouts, response-size limits, credentials disabled and origin allowlists.

## Features

Implemented browser features include:

- responsive desktop/mobile media-center navigation
- Home, Search, Library, Downloads, Sources, History and Settings
- concurrent provider search with timeout/failure isolation, deduplication, ranking and filters
- local bookmarks, watchlist, history, progress and collections
- bulk library selection/watch-state/delete actions
- detail metadata, cast/crew, episode selection, share links and source discovery
- browser-native player with resume seeking, playback speed, PiP, fullscreen, subtitles/WebVTT, subtitle delay/style, source switching, keyboard controls and touch seek
- authorized download queue with pause/resume/retry/cancel/progress/offline Blob reconstruction
- repository add/remove/refresh, web-manifest discovery, explicit install/update/uninstall and enable/disable
- encrypted IndexedDB records for private application state
- AES-GCM encrypted backups
- PBKDF2-based PIN verification with PIN-bound AES-GCM DEK wrapping, throttling and auto-lock/visibility lock
- PWA manifest, service worker, offline shell, update detection and install prompt where the browser supports it
- AMOLED/dark/dim/light/system themes, accent customization, density and reduced-motion preference
- privacy/security headers for Cloudflare Pages

## Setup

Node.js 20+ is recommended.

```bash
npm install
npm run typecheck
npm run lint
npm test
npm run test:security
npm run build
```

For development:

```bash
npm run dev
```

The configured Vite development server uses port `4173`.

### Environment note

The source repository declares Vite and TypeScript as development dependencies. In restricted/offline build environments where `npm install` cannot reach the npm registry, `tools/build.mjs` can produce a TypeScript fallback bundle so the application can still be inspected/tested. A normal connected clone should use the canonical Vite build path.

## Cloudflare Pages

Build:

```bash
npm run build
```

Deploy the `dist/` directory as the Pages output directory.

For Pages:

- Build command: `npm run build`
- Build output directory: `dist`
- SPA fallback: `_redirects`
- Security headers: `_headers`

Attach a custom domain from Cloudflare Pages → Custom domains. Production traffic should be served over HTTPS so HSTS can take effect.

## PWA installation

Chromium-based browsers expose an install prompt when their install criteria are met. On iPhone/iPad, the app uses the browser's supported web-app installation flow; users can use Share → Add to Home Screen when no install prompt is exposed.

## Security model

- HTTPS-only remote URLs
- localhost/private/link-local rejection
- credential-bearing URL rejection
- endpoint origin allowlists
- redirect rejection for provider/repository fetches
- request timeouts and response-size limits
- schema validation for web extension manifests
- no remote code execution
- module Worker extension boundary
- encrypted private records in IndexedDB
- AES-GCM backups
- PBKDF2 PIN verification
- strict Cloudflare-compatible security headers
- no third-party analytics/telemetry SDKs

## Browser limitations

Native `.cs3` CloudStream plugins are intentionally not executable in the web app. Declarative web providers need CORS-compatible HTTPS JSON APIs. Browser support for PiP, Media Session, Remote Playback, native audio-track APIs, persistent downloads and background execution varies by platform. iOS is especially constrained for long-running/background work.

## Testing

Unit/integration security tests are in `tests/*.test.mjs`. `tests/e2e.mjs` uses Chromium and the DevTools protocol when the execution environment permits local browser navigation.

Run:

```bash
npm test
npm run test:security
npm run test:e2e
```

In the development container used for this build, Chromium local navigation is blocked by an administrator policy; this is recorded in the final audit instead of being presented as a successful browser run.

## Project structure

```text
cloudstream-2-web/
├── public/
├── src/
│   ├── app/
│   ├── core/
│   ├── storage/
│   ├── security/
│   ├── extensions/
│   ├── providers/
│   ├── search/
│   ├── library/
│   ├── history/
│   ├── player/
│   ├── downloads/
│   ├── settings/
│   ├── pwa/
│   └── styles.css
├── tests/
├── tools/
├── docs/
├── vite.config.ts
├── _headers
├── _redirects
└── package.json
```

## License

Original code in this repository is released under the MIT License. This project is not affiliated with or endorsed by the CloudStream project.
