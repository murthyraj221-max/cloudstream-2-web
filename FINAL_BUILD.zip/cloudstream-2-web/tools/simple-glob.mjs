import {readdir} from 'node:fs/promises'; import path from 'node:path';
export async function glob(pattern){const out=[];async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())await walk(p);else if(p.endsWith('.ts'))out.push(p);}}await walk('src');return out;}
