import {rm,mkdir,cp,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {existsSync} from 'node:fs';
const root=process.cwd(),dist=path.join(root,'dist');
await rm(dist,{recursive:true,force:true});
const viteBin=path.join(root,'node_modules','vite','bin','vite.js');
if(existsSync(viteBin)){
  execFileSync(process.execPath,[viteBin,'build'],{stdio:'inherit'});
} else {
  execFileSync('tsc',['--pretty','false'],{stdio:'inherit'});
  await mkdir(path.join(dist,'assets'),{recursive:true});
  const html=(await readFile(path.join(root,'index.html'),'utf8')).replace('/src/styles.css','/assets/styles.css').replace('/src/app/main.ts','/assets/app/main.js');
  await writeFile(path.join(dist,'index.html'),html);
  await cp(path.join(root,'public'),dist,{recursive:true});
  await cp(path.join(root,'src','styles.css'),path.join(dist,'assets','styles.css'));
  await cp(path.join(root,'_headers'),path.join(dist,'_headers'));
  console.warn('Vite dependency is unavailable locally; generated an offline TypeScript fallback. Connected builds should execute the Vite pipeline.');
}
console.log('Build output:',dist);
