import {readFile} from 'node:fs/promises';
import {glob} from './simple-glob.mjs';

const files=[...(await glob('src/**/*.ts')),...(await glob('public/**/*')),'index.html','_headers'];
let bad=0;
for(const f of files){
  const s=await readFile(f,'utf8');
  for(const token of ['TODO','FIXME','eval(','new Function(','javascript:']){
    if(s.includes(token)){console.error(`${f}: forbidden token ${token}`);bad++;}
  }
  if(f==='_headers' && /unsafe-inline/.test(s)){console.error('CSP must not contain unsafe-inline.');bad++;}
  if(/<script[^>]+src=["']https?:/i.test(s)){console.error(`${f}: remote script source found.`);bad++;}
}
if(bad)process.exit(1);
console.log(`Static security lint passed for ${files.length} repository files.`);
